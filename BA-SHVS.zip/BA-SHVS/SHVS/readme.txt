To implement this algorithm, run "PFF_test.m". If there is a problem, please contact zhzhzhou@bit.edu.cn

Please cite this paper when using the code:

　Zhou Z, Fei E, Miao L, et al. A perceptual framework for infrared–visible image fusion based on multiscale structure decomposition and biological vision. Information Fusion, 2023, 93: 174-191.