function F = gainv(M)

a = 0.4;
F = 1./(1*(M+1).^a);

end